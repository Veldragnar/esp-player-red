package com.example.model

data class DummyTarget(
    val id: String,
    val name: String,
    val role: String,
    val distanceMeters: Float,
    val health: Int,
    val maxHealth: Int = 100,
    val baseXRatio: Float,    // 0f..1f (center ratio)
    val baseYRatio: Float,    // 0f..1f (center ratio)
    val widthRatio: Float,    // bounding box width ratio
    val heightRatio: Float,   // bounding box height ratio
    val status: String,
    val isLocked: Boolean = false
) {
    companion object {
        fun createSampleTargets(): List<DummyTarget> = listOf(
            DummyTarget(
                id = "T1",
                name = "VIPER",
                role = "SNIPER",
                distanceMeters = 42.8f,
                health = 100,
                baseXRatio = 0.28f,
                baseYRatio = 0.44f,
                widthRatio = 0.22f,
                heightRatio = 0.32f,
                status = "VIGIA COBERTO"
            ),
            DummyTarget(
                id = "T2",
                name = "STRIKER",
                role = "ASSAULT",
                distanceMeters = 18.4f,
                health = 80,
                baseXRatio = 0.68f,
                baseYRatio = 0.50f,
                widthRatio = 0.28f,
                heightRatio = 0.42f,
                status = "AVANÇANDO"
            ),
            DummyTarget(
                id = "T3",
                name = "SPECTER",
                role = "RECON",
                distanceMeters = 76.2f,
                health = 35,
                baseXRatio = 0.48f,
                baseYRatio = 0.34f,
                widthRatio = 0.16f,
                heightRatio = 0.23f,
                status = "FLANQUEANDO"
            )
        )
    }
}
