package com.example.model

data class EspConfig(
    val chamsEnabled: Boolean = true,
    val espBoxEnabled: Boolean = true,
    val espNameEnabled: Boolean = true,
    val espDistanceEnabled: Boolean = true,
    val espHealthEnabled: Boolean = true,
    val outlineEnabled: Boolean = true,
    val glowEnabled: Boolean = true,
    val snaplinesEnabled: Boolean = false,
    val glowIntensity: Float = 0.85f,      // 0.1f - 1.0f
    val outlineThickness: Float = 3.0f,     // 1.0f - 8.0f
    val transparency: Float = 0.90f,        // 0.2f - 1.0f
    val accentColorHex: Long = 0xFFFF1744L,  // Neon Red Default
    val boxCornerOnly: Boolean = true,      // Tactical corner box vs full border
    val radarEnabled: Boolean = true
) {
    companion object {
        val DEFAULT = EspConfig()
        
        val COLOR_OPTIONS = listOf(
            0xFFFF1744L to "Vermelho Neon (Padrão)",
            0xFFFF3D00L to "Laranja Brasa",
            0xFFD50000L to "Vermelho Carmim",
            0xFFE040FBL to "Magenta Cyberpunk",
            0xFF00E5FFL to "Ciano Neon"
        )
    }
}
