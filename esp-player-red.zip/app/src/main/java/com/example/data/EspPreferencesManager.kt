package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.EspConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class EspPreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("esp_player_red_prefs", Context.MODE_PRIVATE)

    private val _configFlow = MutableStateFlow(loadConfig())
    val configFlow: StateFlow<EspConfig> = _configFlow.asStateFlow()

    fun loadConfig(): EspConfig {
        return EspConfig(
            chamsEnabled = prefs.getBoolean(KEY_CHAMS, true),
            espBoxEnabled = prefs.getBoolean(KEY_ESP_BOX, true),
            espNameEnabled = prefs.getBoolean(KEY_ESP_NAME, true),
            espDistanceEnabled = prefs.getBoolean(KEY_ESP_DISTANCE, true),
            espHealthEnabled = prefs.getBoolean(KEY_ESP_HEALTH, true),
            outlineEnabled = prefs.getBoolean(KEY_OUTLINE, true),
            glowEnabled = prefs.getBoolean(KEY_GLOW, true),
            snaplinesEnabled = prefs.getBoolean(KEY_SNAPLINES, false),
            glowIntensity = prefs.getFloat(KEY_GLOW_INTENSITY, 0.85f),
            outlineThickness = prefs.getFloat(KEY_OUTLINE_THICKNESS, 3.0f),
            transparency = prefs.getFloat(KEY_TRANSPARENCY, 0.90f),
            accentColorHex = prefs.getLong(KEY_COLOR_HEX, 0xFFFF1744L),
            boxCornerOnly = prefs.getBoolean(KEY_BOX_CORNER, true),
            radarEnabled = prefs.getBoolean(KEY_RADAR, true)
        )
    }

    fun updateConfig(config: EspConfig) {
        prefs.edit().apply {
            putBoolean(KEY_CHAMS, config.chamsEnabled)
            putBoolean(KEY_ESP_BOX, config.espBoxEnabled)
            putBoolean(KEY_ESP_NAME, config.espNameEnabled)
            putBoolean(KEY_ESP_DISTANCE, config.espDistanceEnabled)
            putBoolean(KEY_ESP_HEALTH, config.espHealthEnabled)
            putBoolean(KEY_OUTLINE, config.outlineEnabled)
            putBoolean(KEY_GLOW, config.glowEnabled)
            putBoolean(KEY_SNAPLINES, config.snaplinesEnabled)
            putFloat(KEY_GLOW_INTENSITY, config.glowIntensity)
            putFloat(KEY_OUTLINE_THICKNESS, config.outlineThickness)
            putFloat(KEY_TRANSPARENCY, config.transparency)
            putLong(KEY_COLOR_HEX, config.accentColorHex)
            putBoolean(KEY_BOX_CORNER, config.boxCornerOnly)
            putBoolean(KEY_RADAR, config.radarEnabled)
            apply()
        }
        _configFlow.value = config
    }

    fun resetToDefaults(): EspConfig {
        val defaultConfig = EspConfig.DEFAULT
        updateConfig(defaultConfig)
        return defaultConfig
    }

    companion object {
        private const val KEY_CHAMS = "key_chams"
        private const val KEY_ESP_BOX = "key_esp_box"
        private const val KEY_ESP_NAME = "key_esp_name"
        private const val KEY_ESP_DISTANCE = "key_esp_distance"
        private const val KEY_ESP_HEALTH = "key_esp_health"
        private const val KEY_OUTLINE = "key_outline"
        private const val KEY_GLOW = "key_glow"
        private const val KEY_SNAPLINES = "key_snaplines"
        private const val KEY_GLOW_INTENSITY = "key_glow_intensity"
        private const val KEY_OUTLINE_THICKNESS = "key_outline_thickness"
        private const val KEY_TRANSPARENCY = "key_transparency"
        private const val KEY_COLOR_HEX = "key_color_hex"
        private const val KEY_BOX_CORNER = "key_box_corner"
        private const val KEY_RADAR = "key_radar"
    }
}
