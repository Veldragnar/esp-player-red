package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.DemoSceneScreen
import com.example.ui.screens.EspMenuScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.EspViewModel

enum class AppScreen {
    HOME,
    ESP_MENU,
    DEMO_SCENE,
    SETTINGS,
    ABOUT
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkBackground)
                ) { innerPadding ->
                    EspPlayerRedApp()
                }
            }
        }
    }
}

@Composable
fun EspPlayerRedApp(
    viewModel: EspViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

    // System Back Handler
    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        currentScreen = AppScreen.HOME
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "screen_transition"
        ) { targetScreen ->
            when (targetScreen) {
                AppScreen.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToDemo = { currentScreen = AppScreen.DEMO_SCENE },
                        onNavigateToEspMenu = { currentScreen = AppScreen.ESP_MENU },
                        onNavigateToSettings = { currentScreen = AppScreen.SETTINGS },
                        onNavigateToAbout = { currentScreen = AppScreen.ABOUT }
                    )
                }

                AppScreen.ESP_MENU -> {
                    EspMenuScreen(
                        viewModel = viewModel,
                        onBackClick = { currentScreen = AppScreen.HOME },
                        onNavigateToDemo = { currentScreen = AppScreen.DEMO_SCENE },
                        onNavigateToSettings = { currentScreen = AppScreen.SETTINGS }
                    )
                }

                AppScreen.DEMO_SCENE -> {
                    DemoSceneScreen(
                        viewModel = viewModel,
                        onBackClick = { currentScreen = AppScreen.HOME },
                        onNavigateToSettings = { currentScreen = AppScreen.SETTINGS }
                    )
                }

                AppScreen.SETTINGS -> {
                    SettingsScreen(
                        viewModel = viewModel,
                        onBackClick = { currentScreen = AppScreen.HOME },
                        onNavigateToDemo = { currentScreen = AppScreen.DEMO_SCENE }
                    )
                }

                AppScreen.ABOUT -> {
                    AboutScreen(
                        onBackClick = { currentScreen = AppScreen.HOME }
                    )
                }
            }
        }
    }
}
