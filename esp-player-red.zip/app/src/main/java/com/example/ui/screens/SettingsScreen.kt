package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.GamerCard
import com.example.components.GamerOutlinedButton
import com.example.components.GamerPrimaryButton
import com.example.components.GamerSliderRow
import com.example.components.GamerTopBar
import com.example.model.EspConfig
import com.example.ui.theme.CrimsonBorder
import com.example.ui.theme.CrimsonDark
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.NeonRed
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.EspViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: EspViewModel,
    onBackClick: () -> Unit,
    onNavigateToDemo: () -> Unit
) {
    val config by viewModel.config.collectAsState()
    val scrollState = rememberScrollState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
        ) {
            GamerTopBar(
                title = "CONFIGURAÇÕES",
                subtitle = "PERSONALIZAÇÃO VISUAL",
                onBackClick = onBackClick
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Interactive Visual Inspector Box
                GamerCard(
                    borderColor = Color(config.accentColorHex).copy(alpha = 0.6f),
                    modifier = Modifier.testTag("visual_inspector_card")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "INSPEÇÃO VISUAL DO HUD",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                            Text(
                                text = "CALIBRAÇÃO A15 5G",
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 10.sp,
                                color = NeonRed
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val previewColor = Color(config.accentColorHex).copy(alpha = config.transparency)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            // Target Box representation
                            Box(
                                modifier = Modifier
                                    .size(width = 120.dp, height = 80.dp)
                                    .border(
                                        width = config.outlineThickness.dp,
                                        color = previewColor,
                                        shape = RoundedCornerShape(if (config.boxCornerOnly) 4.dp else 8.dp)
                                    )
                                    .background(
                                        if (config.chamsEnabled) previewColor.copy(alpha = 0.2f)
                                        else Color.Transparent
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "VIPER [SNIPER]",
                                        fontFamily = RobotoMonoFontFamily,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "35.0m • 100 HP",
                                        fontFamily = RobotoMonoFontFamily,
                                        fontSize = 9.sp,
                                        color = previewColor
                                    )
                                }
                            }

                            // Halo of glow
                            if (config.glowEnabled) {
                                Box(
                                    modifier = Modifier
                                        .size(
                                            width = 120.dp + (config.glowIntensity * 20).dp,
                                            height = 80.dp + (config.glowIntensity * 20).dp
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = previewColor.copy(alpha = config.glowIntensity * 0.45f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Customization Sliders Card
                GamerCard(borderColor = CrimsonBorder) {
                    Column {
                        Text(
                            text = "PARÂMETROS DE RENDERIZAÇÃO",
                            fontFamily = OrbitronFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // 1. Controle de intensidade do brilho
                        GamerSliderRow(
                            label = "Intensidade do Brilho (Glow)",
                            value = config.glowIntensity,
                            onValueChange = { viewModel.setGlowIntensity(it) },
                            valueRange = 0.1f..1.0f,
                            valueFormatted = "${(config.glowIntensity * 100).toInt()}%",
                            testTag = "slider_glow"
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // 2. Controle de espessura do contorno
                        GamerSliderRow(
                            label = "Espessura do Contorno (Thickness)",
                            value = config.outlineThickness,
                            onValueChange = { viewModel.setOutlineThickness(it) },
                            valueRange = 1.0f..8.0f,
                            valueFormatted = "%.1f dp".format(config.outlineThickness),
                            testTag = "slider_thickness"
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // 3. Controle de transparência
                        GamerSliderRow(
                            label = "Transparência / Opacidade",
                            value = config.transparency,
                            onValueChange = { viewModel.setTransparency(it) },
                            valueRange = 0.2f..1.0f,
                            valueFormatted = "${(config.transparency * 100).toInt()}%",
                            testTag = "slider_transparency"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Color Selection Card
                GamerCard(borderColor = CrimsonBorder) {
                    Column {
                        Text(
                            text = "PALETA DE COR DO HUD",
                            fontFamily = OrbitronFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                        Text(
                            text = "Vermelho Neon é o padrão oficial RED EDITION",
                            fontFamily = RobotoMonoFontFamily,
                            fontSize = 11.sp,
                            color = TextMuted
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        EspConfig.COLOR_OPTIONS.forEach { (colorHex, name) ->
                            val isSelected = config.accentColorHex == colorHex
                            val color = Color(colorHex)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) CrimsonDark else DarkSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (isSelected) color else DarkSurfaceHighlight,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { viewModel.setAccentColor(colorHex) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selecionado",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = name,
                                    fontFamily = OrbitronFontFamily,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Box Style Selection
                GamerCard(borderColor = CrimsonBorder) {
                    Column {
                        Text(
                            text = "ESTILO DA CAIXA ESP",
                            fontFamily = OrbitronFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val cornerSelected = config.boxCornerOnly
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (cornerSelected) CrimsonDark else DarkSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (cornerSelected) NeonRed else DarkSurfaceHighlight,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { viewModel.setBoxCornerOnly(true) }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "┌       ┐\n└       ┘",
                                        fontFamily = RobotoMonoFontFamily,
                                        fontSize = 16.sp,
                                        color = if (cornerSelected) NeonRed else TextMuted
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "CANTOS TÁTICOS",
                                        fontFamily = OrbitronFontFamily,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (cornerSelected) TextPrimary else TextSecondary
                                    )
                                }
                            }

                            val fullSelected = !config.boxCornerOnly
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (fullSelected) CrimsonDark else DarkSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (fullSelected) NeonRed else DarkSurfaceHighlight,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { viewModel.setBoxCornerOnly(false) }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "┌───────┐\n└───────┘",
                                        fontFamily = RobotoMonoFontFamily,
                                        fontSize = 16.sp,
                                        color = if (fullSelected) NeonRed else TextMuted
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "CAIXA COMPLETA",
                                        fontFamily = OrbitronFontFamily,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (fullSelected) TextPrimary else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Reset to Defaults Button
                GamerOutlinedButton(
                    text = "RESTAURAR CONFIGURAÇÕES PADRÃO",
                    onClick = {
                        viewModel.resetDefaults()
                        scope.launch {
                            snackbarHostState.showSnackbar("Configurações restauradas para o padrão RED EDITION!")
                        }
                    },
                    icon = Icons.Default.Refresh,
                    testTag = "btn_reset_defaults"
                )

                Spacer(modifier = Modifier.height(12.dp))

                GamerPrimaryButton(
                    text = "TESTAR NA DEMONSTRAÇÃO",
                    onClick = onNavigateToDemo,
                    icon = Icons.Default.PlayArrow,
                    testTag = "btn_demo_from_settings"
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
        )
    }
}
