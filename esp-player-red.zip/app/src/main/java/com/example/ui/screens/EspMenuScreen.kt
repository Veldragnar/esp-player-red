package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.GamerCard
import com.example.components.GamerOutlinedButton
import com.example.components.GamerPrimaryButton
import com.example.components.GamerSwitchRow
import com.example.components.GamerTopBar
import com.example.ui.theme.CrimsonBorder
import com.example.ui.theme.CrimsonDark
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.EspViewModel

@Composable
fun EspMenuScreen(
    viewModel: EspViewModel,
    onBackClick: () -> Unit,
    onNavigateToDemo: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val config by viewModel.config.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        GamerTopBar(
            title = "MENU ESP",
            subtitle = "INTERRUPTORES INDEPENDENTES",
            onBackClick = onBackClick,
            actions = {
                IconButton(
                    onClick = { viewModel.resetDefaults() },
                    modifier = Modifier.testTag("btn_reset_menu")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Restaurar",
                        tint = NeonRed
                    )
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Live Preview Card
            GamerCard(
                borderColor = NeonRed.copy(alpha = 0.5f),
                modifier = Modifier.testTag("esp_preview_card")
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PRÉ-VISUALIZAÇÃO EM TEMPO REAL",
                            fontFamily = OrbitronFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                        Text(
                            text = "ALVO FICTÍCIO [T1]",
                            fontFamily = RobotoMonoFontFamily,
                            fontSize = 10.sp,
                            color = NeonRedBright
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Simulated target preview box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        // Simulated Target Silhouette and ESP elements
                        val accentColor = Color(config.accentColorHex).copy(alpha = config.transparency)

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .border(
                                    width = if (config.espBoxEnabled) config.outlineThickness.dp else 0.dp,
                                    color = if (config.espBoxEnabled) accentColor else Color.Transparent,
                                    shape = RoundedCornerShape(if (config.boxCornerOnly) 4.dp else 8.dp)
                                )
                                .background(
                                    if (config.chamsEnabled) accentColor.copy(alpha = 0.25f * config.transparency)
                                    else Color.Transparent
                                )
                                .padding(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            if (config.espNameEnabled) {
                                Text(
                                    text = "TARGET • VIPER [SNIPER]",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // Outline / Silhouette placeholder
                            Box(
                                modifier = Modifier
                                    .size(width = 36.dp, height = 36.dp)
                                    .border(
                                        width = if (config.outlineEnabled) 2.dp else 0.dp,
                                        color = if (config.outlineEnabled) accentColor else Color.Transparent,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .background(
                                        if (config.chamsEnabled) accentColor.copy(alpha = 0.4f)
                                        else CrimsonDark.copy(alpha = 0.3f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "👤",
                                    fontSize = 18.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            if (config.espHealthEnabled) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(50.dp)
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(Color.DarkGray)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth(0.85f)
                                                .height(4.dp)
                                                .background(CyberGreen)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "85 HP",
                                        fontFamily = RobotoMonoFontFamily,
                                        fontSize = 9.sp,
                                        color = CyberGreen
                                    )
                                }
                            }

                            if (config.espDistanceEnabled) {
                                Text(
                                    text = "[42.8m]",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = NeonRedBright
                                )
                            }
                        }

                        if (config.glowEnabled) {
                            Box(
                                modifier = Modifier
                                    .size(110.dp, 100.dp)
                                    .border(
                                        1.dp,
                                        accentColor.copy(alpha = config.glowIntensity * 0.4f),
                                        RoundedCornerShape(8.dp)
                                    )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "INTERRUPTORES ESP PRINCIPAIS",
                fontFamily = OrbitronFontFamily,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            // 1. CHAMS DEMO
            GamerSwitchRow(
                title = "1. CHAMS DEMO",
                description = "Preenchimento térmico neon sobre a silhueta do alvo",
                checked = config.chamsEnabled,
                onCheckedChange = { viewModel.toggleChams(it) },
                badgeNumber = "1",
                testTag = "switch_chams"
            )

            // 2. ESP BOX DEMO
            GamerSwitchRow(
                title = "2. ESP BOX DEMO",
                description = "Caixa delimitadora 2D tática ao redor do operador",
                checked = config.espBoxEnabled,
                onCheckedChange = { viewModel.toggleEspBox(it) },
                badgeNumber = "2",
                testTag = "switch_box"
            )

            // 3. ESP NAME DEMO
            GamerSwitchRow(
                title = "3. ESP NAME DEMO",
                description = "Etiqueta com codinome e função tática fictícia",
                checked = config.espNameEnabled,
                onCheckedChange = { viewModel.toggleEspName(it) },
                badgeNumber = "3",
                testTag = "switch_name"
            )

            // 4. ESP DISTANCE DEMO
            GamerSwitchRow(
                title = "4. ESP DISTANCE DEMO",
                description = "Telemetria métrica de alcance do alvo em metros",
                checked = config.espDistanceEnabled,
                onCheckedChange = { viewModel.toggleEspDistance(it) },
                badgeNumber = "4",
                testTag = "switch_distance"
            )

            // 5. ESP HEALTH DEMO
            GamerSwitchRow(
                title = "5. ESP HEALTH DEMO",
                description = "Barra de integridade e indicador numérico de HP",
                checked = config.espHealthEnabled,
                onCheckedChange = { viewModel.toggleEspHealth(it) },
                badgeNumber = "5",
                testTag = "switch_health"
            )

            // 6. OUTLINE DEMO
            GamerSwitchRow(
                title = "6. OUTLINE DEMO",
                description = "Linha de contorno exterior de alta nitidez",
                checked = config.outlineEnabled,
                onCheckedChange = { viewModel.toggleOutline(it) },
                badgeNumber = "6",
                testTag = "switch_outline"
            )

            // 7. GLOW DEMO
            GamerSwitchRow(
                title = "7. GLOW DEMO",
                description = "Efeito de radiação de brilho e aura vermelha neon",
                checked = config.glowEnabled,
                onCheckedChange = { viewModel.toggleGlow(it) },
                badgeNumber = "7",
                testTag = "switch_glow"
            )

            // EXTRA: SNAPLINES DEMO
            GamerSwitchRow(
                title = "SNAPLINES / RADAR VETORIAL",
                description = "Vetor tático do centro inferior até o alvo",
                checked = config.snaplinesEnabled,
                onCheckedChange = { viewModel.toggleSnaplines(it) },
                badgeNumber = "+",
                testTag = "switch_snaplines"
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Actions
            GamerPrimaryButton(
                text = "ABRIR NA CENA DE DEMONSTRAÇÃO",
                onClick = onNavigateToDemo,
                icon = Icons.Default.PlayArrow,
                testTag = "btn_demo_from_menu"
            )

            Spacer(modifier = Modifier.height(10.dp))

            GamerOutlinedButton(
                text = "AJUSTAR BRILHO, ESPESSURA E COR",
                onClick = onNavigateToSettings,
                icon = Icons.Default.Tune,
                testTag = "btn_tune_from_menu"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
