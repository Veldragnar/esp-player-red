package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Red Gaming Palette
val NeonRed = Color(0xFFFF1744)
val NeonRedBright = Color(0xFFFF3D57)
val NeonRedGlow = Color(0x66FF1744)
val CrimsonDark = Color(0xFF26050A)
val CrimsonBorder = Color(0xFF4D0F19)

val DarkBackground = Color(0xFF070709)
val DarkSurface = Color(0xFF0F0F14)
val DarkSurfaceElevated = Color(0xFF161620)
val DarkSurfaceHighlight = Color(0xFF1E1E2C)

val TextPrimary = Color(0xFFF2F2F7)
val TextSecondary = Color(0xFFA0A0B2)
val TextMuted = Color(0xFF6B6B7F)

val CyberGreen = Color(0xFF00E676)
val CyberAmber = Color(0xFFFF9100)
val CyberBlue = Color(0xFF00E5FF)
