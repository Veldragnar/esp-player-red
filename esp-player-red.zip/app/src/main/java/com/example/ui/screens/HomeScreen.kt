package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.components.GamerCard
import com.example.components.GamerOutlinedButton
import com.example.components.GamerPrimaryButton
import com.example.components.PulsingStatusBadge
import com.example.ui.theme.CrimsonBorder
import com.example.ui.theme.CrimsonDark
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.EspViewModel

@Composable
fun HomeScreen(
    viewModel: EspViewModel,
    onNavigateToDemo: () -> Unit,
    onNavigateToEspMenu: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val config by viewModel.config.collectAsState()
    val scrollState = rememberScrollState()

    val activeModulesCount = listOf(
        config.chamsEnabled,
        config.espBoxEnabled,
        config.espNameEnabled,
        config.espDistanceEnabled,
        config.espHealthEnabled,
        config.outlineEnabled,
        config.glowEnabled
    ).count { it }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Brand Header with Tactical Icon
            Box(
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(NeonRed.copy(alpha = 0.25f), CrimsonDark)
                        )
                    )
                    .border(2.dp, NeonRed, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.esp_launcher_icon),
                    contentDescription = "ESP Player Logo",
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "ESP PLAYER",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Black,
                fontSize = 26.sp,
                letterSpacing = 2.sp,
                color = TextPrimary
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonRed)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "RED EDITION",
                        fontFamily = OrbitronFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "v2.5 PRO • DEMO ENGINE",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Real-Time System Status Card
            GamerCard(
                modifier = Modifier.testTag("status_card"),
                borderColor = if (activeModulesCount > 0) NeonRed.copy(alpha = 0.5f) else CrimsonBorder
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STATUS DO SISTEMA",
                            fontFamily = OrbitronFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                        PulsingStatusBadge(
                            statusText = "SISTEMA ONLINE",
                            color = CyberGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DarkSurfaceElevated)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Samsung Galaxy A15 5G",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Taxa 90Hz • 1080x2340 FHD+ Otimizado",
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 11.sp,
                                color = NeonRedBright
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(CrimsonDark)
                                .border(1.dp, NeonRed, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "$activeModulesCount/7 ATIVOS",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Protótipo funcional demonstrativo. Renderização vetorial e holográfica local em tempo real.",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Navigation Buttons
            Text(
                text = "PAINEL DE OPERAÇÃO",
                fontFamily = OrbitronFontFamily,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            )

            GamerPrimaryButton(
                text = "ABRIR DEMONSTRAÇÃO",
                onClick = onNavigateToDemo,
                icon = Icons.Default.PlayArrow,
                testTag = "btn_open_demo"
            )

            Spacer(modifier = Modifier.height(12.dp))

            GamerOutlinedButton(
                text = "MENU ESP (INTERRUPTORES)",
                onClick = onNavigateToEspMenu,
                icon = Icons.Default.Visibility,
                testTag = "btn_esp_menu"
            )

            Spacer(modifier = Modifier.height(12.dp))

            GamerOutlinedButton(
                text = "CONFIGURAÇÕES VISUAIS",
                onClick = onNavigateToSettings,
                icon = Icons.Default.Tune,
                testTag = "btn_settings"
            )

            Spacer(modifier = Modifier.height(12.dp))

            GamerOutlinedButton(
                text = "SOBRE O APLICATIVO",
                onClick = onNavigateToAbout,
                icon = Icons.Default.Info,
                testTag = "btn_about"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Quick Toggle Summary Box
            GamerCard(borderColor = CrimsonBorder) {
                Column {
                    Text(
                        text = "RESUMO DOS RECURSOS ESP",
                        fontFamily = OrbitronFontFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val features = listOf(
                        "CHAMS" to config.chamsEnabled,
                        "BOX" to config.espBoxEnabled,
                        "NAME" to config.espNameEnabled,
                        "DIST" to config.espDistanceEnabled,
                        "HEALTH" to config.espHealthEnabled,
                        "OUTLINE" to config.outlineEnabled,
                        "GLOW" to config.glowEnabled
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        features.forEach { (name, enabled) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (enabled) NeonRed else DarkSurfaceHighlight)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = name,
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = if (enabled) TextPrimary else TextMuted
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
