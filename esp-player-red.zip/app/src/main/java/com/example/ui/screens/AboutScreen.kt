package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.components.GamerCard
import com.example.components.GamerTopBar
import com.example.ui.theme.CrimsonBorder
import com.example.ui.theme.CrimsonDark
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AboutScreen(
    onBackClick: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        GamerTopBar(
            title = "SOBRE O APP",
            subtitle = "INFORMAÇÕES & GUIA DO APK",
            onBackClick = onBackClick
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("about_screen_content")
        ) {
            // App Identity Card
            GamerCard(borderColor = NeonRed.copy(alpha = 0.5f)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(NeonRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "ESP",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ESP PLAYER RED EDITION",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            Text(
                                text = "Versão 2.5 Pro • Engine de Demonstração Gamer",
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 11.sp,
                                color = NeonRedBright
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Interface gamer profissional projetada para visualização, calibração e teste interativo de efeitos de telemetria visual (Chams, Box 2D, Distância, Nomes fictícios, Barra de HP, Glow e Outline) com renderização em tempo real.",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Ethical Notice Card
            GamerCard(borderColor = CrimsonBorder) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = CyberGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AVISO DE CONFORMIDADE & SEGURANÇA",
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = CyberGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Este aplicativo é um protótipo visual educativo e autônomo. Ele opera inteiramente em sua própria cena simulada e NÃO acessa, intercepta nem modifica a memória de outros jogos (como Blood Strike ou quaisquer outros títulos). 100% seguro e compatível com as diretrizes do Android.",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 11.sp,
                        color = TextMuted,
                        lineHeight = 17.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hardware Optimization Profile
            GamerCard(borderColor = CrimsonBorder) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = null,
                            tint = NeonRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PERFIL SAMSUNG GALAXY A15 5G",
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    SpecItem(label = "Tela", value = "6.5\" Super AMOLED (1080 x 2340)")
                    SpecItem(label = "Taxa de Atualização", value = "90 Hz Otimizado")
                    SpecItem(label = "Processador / GPU", value = "MediaTek Dimensity 6100+ / Mali-G57")
                    SpecItem(label = "Tempo de Resposta", value = "~11 ms (Renderização local)")
                    SpecItem(label = "Consumo de Bateria", value = "Otimizado para baixo overhead")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Step-by-Step APK Build and Install Guide
            GamerCard(borderColor = NeonRed.copy(alpha = 0.5f)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = null,
                            tint = NeonRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "COMO COMPILAR E INSTALAR O APK",
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TutorialStep(
                        step = "1",
                        title = "Download Direto pelo AI Studio",
                        desc = "Clique no menu do projeto no canto superior direito e selecione a opção de gerar/baixar o arquivo APK diretamente para o seu computador ou celular."
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TutorialStep(
                        step = "2",
                        title = "Compilação Manual via Gradle",
                        desc = "Para compilar localmente no Android Studio ou terminal Linux/Mac/Windows, execute:\ngradle assembleDebug\nO APK gerado ficará em app/build/outputs/apk/debug/app-debug.apk."
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TutorialStep(
                        step = "3",
                        title = "Instalar no Samsung Galaxy A15 5G",
                        desc = "Transfira o arquivo APK para o celular (ou baixe diretamente pelo navegador do aparelho). Ao abrir o APK, o Android One UI solicitará permissão para 'Instalar apps de fontes desconhecidas'. Toque em Permitir e conclua a instalação."
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TutorialStep(
                        step = "4",
                        title = "Ativar 90Hz Suavidade Máxima",
                        desc = "No seu Galaxy A15 5G, acesse: Configurações > Visor > Suavidade do movimento e escolha 'Alta (90 Hz)' para usufruir da experiência mais fluida."
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SpecItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontFamily = RobotoMonoFontFamily,
            fontSize = 11.sp,
            color = TextMuted
        )
        Text(
            text = value,
            fontFamily = RobotoMonoFontFamily,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}

@Composable
fun TutorialStep(step: String, title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceElevated)
            .padding(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(NeonRed),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = step,
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = Color.White
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                fontFamily = RobotoMonoFontFamily,
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )
        }
    }
}
