package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RedEditionColorScheme = darkColorScheme(
    primary = NeonRed,
    onPrimary = Color.White,
    primaryContainer = CrimsonDark,
    onPrimaryContainer = NeonRedBright,
    secondary = NeonRedBright,
    onSecondary = Color.White,
    secondaryContainer = CrimsonBorder,
    onSecondaryContainer = Color.White,
    tertiary = CyberGreen,
    onTertiary = Color.Black,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CrimsonBorder,
    outlineVariant = DarkSurfaceHighlight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RedEditionColorScheme,
        typography = Typography,
        content = content
    )
}
