package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DummyTarget
import com.example.model.EspConfig
import com.example.ui.theme.CrimsonBorder
import com.example.ui.theme.CrimsonDark
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.EspViewModel
import kotlin.math.roundToInt

@Composable
fun DemoSceneScreen(
    viewModel: EspViewModel,
    onBackClick: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val config by viewModel.config.collectAsState()
    val targets by viewModel.targets.collectAsState()
    val selectedTargetId by viewModel.selectedTargetId.collectAsState()
    val cameraPanX by viewModel.cameraPanX.collectAsState()
    val cameraPanY by viewModel.cameraPanY.collectAsState()

    var showQuickHUD by remember { mutableStateOf(true) }

    // Floating animation for live tactical feel
    val infiniteTransition = rememberInfiniteTransition(label = "drift")
    val swayAnim by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sway"
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    viewModel.onPan(dragAmount.x * 0.4f, dragAmount.y * 0.4f)
                }
            }
            .testTag("demo_scene_root")
    ) {
        val arenaWidth = constraints.maxWidth.toFloat()
        val arenaHeight = constraints.maxHeight.toFloat()
        val accentColor = Color(config.accentColorHex).copy(alpha = config.transparency)

        // 1. Tactical Arena Backdrop (9:16 aspect ratio game scene)
        Image(
            painter = painterResource(id = R.drawable.esp_demo_backdrop),
            contentDescription = "Tactical Arena Backdrop",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .offset {
                    IntOffset(
                        x = (cameraPanX * 0.6f).roundToInt(),
                        y = (cameraPanY * 0.6f).roundToInt()
                    )
                }
        )

        // Dark gradient overlay for tactical readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.65f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // 2. Tactical Vector Canvas (Snaplines, Grid, Reticle)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val bottomOrigin = Offset(size.width / 2f, size.height * 0.92f)

            // Draw snaplines from bottom center to each active target base
            if (config.snaplinesEnabled) {
                targets.forEach { target ->
                    val tx = (target.baseXRatio * size.width) + cameraPanX + (if (target.id == "T2") swayAnim * 4 else 0f)
                    val ty = (target.baseYRatio * size.height) + cameraPanY + (target.heightRatio * size.height / 2f)

                    drawLine(
                        color = accentColor.copy(alpha = 0.6f * config.transparency),
                        start = bottomOrigin,
                        end = Offset(tx, ty),
                        strokeWidth = (config.outlineThickness * 0.8f).dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                    )

                    // Target base marker point
                    drawCircle(
                        color = accentColor,
                        radius = 4.dp.toPx(),
                        center = Offset(tx, ty)
                    )
                }
            }

            // Central Tactical Crosshair Reticle
            val cx = size.width / 2f
            val cy = size.height / 2f
            val crosshairColor = NeonRed.copy(alpha = 0.75f)

            // Center ring & reticle marks
            drawCircle(
                color = crosshairColor,
                radius = 12.dp.toPx(),
                style = Stroke(width = 1.5.dp.toPx())
            )
            drawCircle(
                color = crosshairColor,
                radius = 2.dp.toPx()
            )
            // Left, Right, Top, Bottom crosshair tick marks
            drawLine(crosshairColor, Offset(cx - 24.dp.toPx(), cy), Offset(cx - 14.dp.toPx(), cy), strokeWidth = 2.dp.toPx())
            drawLine(crosshairColor, Offset(cx + 14.dp.toPx(), cy), Offset(cx + 24.dp.toPx(), cy), strokeWidth = 2.dp.toPx())
            drawLine(crosshairColor, Offset(cx, cy - 24.dp.toPx()), Offset(cx, cy - 14.dp.toPx()), strokeWidth = 2.dp.toPx())
            drawLine(crosshairColor, Offset(cx, cy + 14.dp.toPx()), Offset(cx, cy + 24.dp.toPx()), strokeWidth = 2.dp.toPx())
        }

        // 3. Render Simulated Targets with all requested ESP effects
        targets.forEach { target ->
            val isTargetSelected = target.id == selectedTargetId

            // Normalized position adjusted for camera pan and target sway
            val dynamicSway = if (target.id == "T2") swayAnim * 4 else (if (target.id == "T1") swayAnim * -2 else 0f)
            val posX = (target.baseXRatio * arenaWidth) + cameraPanX + dynamicSway
            val posY = (target.baseYRatio * arenaHeight) + cameraPanY

            val boxWidth = (target.widthRatio * arenaWidth).coerceAtLeast(70f)
            val boxHeight = (target.heightRatio * arenaHeight).coerceAtLeast(110f)

            val left = posX - (boxWidth / 2f)
            val top = posY - (boxHeight / 2f)

            Box(
                modifier = Modifier
                    .offset { IntOffset(left.roundToInt(), top.roundToInt()) }
                    .size(width = boxWidth.dp, height = boxHeight.dp)
                    .clickable {
                        viewModel.selectTarget(target.id)
                    }
                    .testTag("target_${target.id}")
            ) {
                // Glow Halo
                if (config.glowEnabled) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding((-4).dp)
                            .border(
                                width = (config.outlineThickness + (config.glowIntensity * 4)).dp,
                                color = accentColor.copy(alpha = config.glowIntensity * 0.35f),
                                shape = RoundedCornerShape(8.dp)
                            )
                    )
                }

                // CHAMS DEMO: Holographic filled silhouette
                if (config.chamsEnabled) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        accentColor.copy(alpha = 0.45f * config.transparency),
                                        accentColor.copy(alpha = 0.20f * config.transparency),
                                        accentColor.copy(alpha = 0.50f * config.transparency)
                                    )
                                )
                            )
                    ) {
                        // Futuristic wireframe dummy representation inside CHAMS
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            // Head silhouette
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(accentColor.copy(alpha = 0.6f))
                                    .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            // Torso silhouette
                            Box(
                                modifier = Modifier
                                    .width(36.dp)
                                    .height(42.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(accentColor.copy(alpha = 0.5f))
                                    .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            // Legs silhouette
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(
                                    modifier = Modifier
                                        .width(12.dp)
                                        .height(38.dp)
                                        .background(accentColor.copy(alpha = 0.5f))
                                )
                                Box(
                                    modifier = Modifier
                                        .width(12.dp)
                                        .height(38.dp)
                                        .background(accentColor.copy(alpha = 0.5f))
                                )
                            }
                        }
                    }
                }

                // OUTLINE DEMO
                if (config.outlineEnabled) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .border(
                                width = 1.dp,
                                color = Color.White.copy(alpha = 0.85f * config.transparency),
                                shape = RoundedCornerShape(4.dp)
                            )
                    )
                }

                // ESP BOX DEMO
                if (config.espBoxEnabled) {
                    if (config.boxCornerOnly) {
                        // Tactical Corner Brackets
                        TacticalCornersBox(
                            color = accentColor,
                            thickness = config.outlineThickness.dp
                        )
                    } else {
                        // Full Box
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .border(
                                    width = config.outlineThickness.dp,
                                    color = accentColor,
                                    shape = RoundedCornerShape(4.dp)
                                )
                        )
                    }
                }

                // ESP HEALTH DEMO: Vertical HP bar on the left edge
                if (config.espHealthEnabled) {
                    val hpRatio = (target.health / target.maxHealth.toFloat()).coerceIn(0f, 1f)
                    val hpColor = when {
                        hpRatio > 0.6f -> CyberGreen
                        hpRatio > 0.3f -> CyberAmber
                        else -> NeonRed
                    }

                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .offset(x = (-10).dp)
                            .height((boxHeight * 0.85f).dp)
                            .width(5.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .border(0.5.dp, Color.DarkGray, RoundedCornerShape(2.dp)),
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f - hpRatio, fill = hpRatio < 1f)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(hpRatio, fill = true)
                                .background(hpColor)
                        )
                    }
                }

                // ESP NAME DEMO + ROLE TAG: Above the box
                if (config.espNameEnabled) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = (-24).dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black.copy(alpha = 0.85f))
                            .border(1.dp, accentColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "[${target.id}] ${target.name} • ${target.role}",
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            color = Color.White
                        )
                    }
                }

                // ESP DISTANCE DEMO + HEALTH READOUT: Below the box
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (config.espDistanceEnabled) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color.Black.copy(alpha = 0.8f))
                                .border(0.5.dp, CrimsonBorder, RoundedCornerShape(3.dp))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "%.1fm".format(target.distanceMeters),
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = NeonRedBright
                            )
                        }
                    }

                    if (config.espHealthEnabled) {
                        Text(
                            text = "${target.health} HP",
                            fontFamily = RobotoMonoFontFamily,
                            fontSize = 8.sp,
                            color = if (target.health > 50) CyberGreen else NeonRed
                        )
                    }
                }
            }
        }

        // 4. TOP HUD TELEMETRY BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .border(1.dp, CrimsonBorder, RoundedCornerShape(10.dp))
                    .testTag("btn_back_demo")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Voltar",
                    tint = NeonRed
                )
            }

            // Real-Time Telemetry Stats Card
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .border(1.dp, CrimsonBorder, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(CyberGreen)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "90.0 FPS • 11ms",
                        fontFamily = OrbitronFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberGreen
                    )
                }
                Text(
                    text = "GALAXY A15 5G • 1080x2340",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = TextMuted
                )
                Text(
                    text = "ALVOS DETECTADOS: 3/3",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonRedBright
                )
            }
        }

        // 5. Selected Target Interactive Actions (Damage test & Reset Camera)
        if (selectedTargetId != null) {
            val locked = targets.find { it.id == selectedTargetId }
            if (locked != null) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 70.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = 0.85f))
                        .border(1.dp, NeonRed, RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ALVO [${locked.id}]: ${locked.name} (${locked.health}HP)",
                        fontFamily = OrbitronFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NeonRed)
                            .clickable { viewModel.damageTarget(locked.id, 25) }
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "DISPARO -25 HP",
                            fontFamily = RobotoMonoFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Camera Pan Reset & Settings Button Floating on Right Edge
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = { viewModel.resetCamera() },
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.75f))
                    .border(1.dp, CrimsonBorder, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.CenterFocusStrong,
                    contentDescription = "Recentralizar Câmera",
                    tint = Color.White
                )
            }

            IconButton(
                onClick = onNavigateToSettings,
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.75f))
                    .border(1.dp, CrimsonBorder, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Configurações",
                    tint = NeonRed
                )
            }
        }

        // Drag Helper Tip (Dismisses or reminds user)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = if (showQuickHUD) 120.dp else 24.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = 0.65f))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Text(
                text = "Arraste na tela para mover a visão 360° • Toque no alvo para testar",
                fontFamily = RobotoMonoFontFamily,
                fontSize = 10.sp,
                color = TextSecondary
            )
        }

        // 6. IN-DEMO QUICK TOGGLE HUD OVERLAY (Bottom Sheet Strip)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .background(Color.Black.copy(alpha = 0.90f))
                .border(1.dp, CrimsonBorder, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .testTag("in_demo_quick_hud")
        ) {
            // Header bar to expand/collapse
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showQuickHUD = !showQuickHUD }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = NeonRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CONTROLES RÁPIDOS ESP",
                        fontFamily = OrbitronFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Icon(
                    imageVector = if (showQuickHUD) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                    contentDescription = if (showQuickHUD) "Minimizar" else "Expandir",
                    tint = TextSecondary
                )
            }

            AnimatedVisibility(
                visible = showQuickHUD,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    // Row 1 of quick chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DemoQuickChip(
                            label = "CHAMS",
                            selected = config.chamsEnabled,
                            onToggle = { viewModel.toggleChams(!config.chamsEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                        DemoQuickChip(
                            label = "BOX",
                            selected = config.espBoxEnabled,
                            onToggle = { viewModel.toggleEspBox(!config.espBoxEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                        DemoQuickChip(
                            label = "NAME",
                            selected = config.espNameEnabled,
                            onToggle = { viewModel.toggleEspName(!config.espNameEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                        DemoQuickChip(
                            label = "DIST",
                            selected = config.espDistanceEnabled,
                            onToggle = { viewModel.toggleEspDistance(!config.espDistanceEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Row 2 of quick chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DemoQuickChip(
                            label = "HEALTH",
                            selected = config.espHealthEnabled,
                            onToggle = { viewModel.toggleEspHealth(!config.espHealthEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                        DemoQuickChip(
                            label = "OUTLINE",
                            selected = config.outlineEnabled,
                            onToggle = { viewModel.toggleOutline(!config.outlineEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                        DemoQuickChip(
                            label = "GLOW",
                            selected = config.glowEnabled,
                            onToggle = { viewModel.toggleGlow(!config.glowEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                        DemoQuickChip(
                            label = "SNAPLINE",
                            selected = config.snaplinesEnabled,
                            onToggle = { viewModel.toggleSnaplines(!config.snaplinesEnabled) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
fun TacticalCornersBox(
    color: Color,
    thickness: androidx.compose.ui.unit.Dp
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokePx = thickness.toPx()
        val cornerLen = (size.width * 0.28f).coerceAtLeast(14.dp.toPx())

        // Top-Left corner
        drawLine(color, Offset(0f, 0f), Offset(cornerLen, 0f), strokePx)
        drawLine(color, Offset(0f, 0f), Offset(0f, cornerLen), strokePx)

        // Top-Right corner
        drawLine(color, Offset(size.width, 0f), Offset(size.width - cornerLen, 0f), strokePx)
        drawLine(color, Offset(size.width, 0f), Offset(size.width, cornerLen), strokePx)

        // Bottom-Left corner
        drawLine(color, Offset(0f, size.height), Offset(cornerLen, size.height), strokePx)
        drawLine(color, Offset(0f, size.height), Offset(0f, size.height - cornerLen), strokePx)

        // Bottom-Right corner
        drawLine(color, Offset(size.width, size.height), Offset(size.width - cornerLen, size.height), strokePx)
        drawLine(color, Offset(size.width, size.height), Offset(size.width, size.height - cornerLen), strokePx)
    }
}

@Composable
fun DemoQuickChip(
    label: String,
    selected: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) NeonRed else DarkSurfaceElevated)
            .border(
                1.dp,
                if (selected) NeonRedBright else DarkSurfaceHighlight,
                RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onToggle),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontFamily = OrbitronFontFamily,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) Color.White else TextMuted
        )
    }
}
