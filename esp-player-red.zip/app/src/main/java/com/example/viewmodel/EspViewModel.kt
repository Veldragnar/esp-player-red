package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.data.EspPreferencesManager
import com.example.model.DummyTarget
import com.example.model.EspConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class EspViewModel(application: Application) : AndroidViewModel(application) {
    private val preferencesManager = EspPreferencesManager(application)

    val config: StateFlow<EspConfig> = preferencesManager.configFlow

    private val _targets = MutableStateFlow(DummyTarget.createSampleTargets())
    val targets: StateFlow<List<DummyTarget>> = _targets.asStateFlow()

    private val _selectedTargetId = MutableStateFlow<String?>("T2")
    val selectedTargetId: StateFlow<String?> = _selectedTargetId.asStateFlow()

    // Camera pan offset driven by user touch gestures
    private val _cameraPanX = MutableStateFlow(0f)
    val cameraPanX: StateFlow<Float> = _cameraPanX.asStateFlow()

    private val _cameraPanY = MutableStateFlow(0f)
    val cameraPanY: StateFlow<Float> = _cameraPanY.asStateFlow()

    fun onPan(deltaX: Float, deltaY: Float) {
        _cameraPanX.value = (_cameraPanX.value + deltaX).coerceIn(-180f, 180f)
        _cameraPanY.value = (_cameraPanY.value + deltaY).coerceIn(-90f, 90f)
    }

    fun resetCamera() {
        _cameraPanX.value = 0f
        _cameraPanY.value = 0f
    }

    fun selectTarget(id: String) {
        _selectedTargetId.value = if (_selectedTargetId.value == id) null else id
        _targets.value = _targets.value.map { target ->
            if (target.id == id) {
                target.copy(isLocked = !target.isLocked)
            } else {
                target.copy(isLocked = false)
            }
        }
    }

    fun damageTarget(id: String, amount: Int = 20) {
        _targets.value = _targets.value.map { target ->
            if (target.id == id) {
                val newHp = (target.health - amount).let { if (it <= 0) 100 else it }
                target.copy(health = newHp)
            } else target
        }
    }

    // Toggle specific ESP features
    fun toggleChams(enabled: Boolean) = updateConfig { it.copy(chamsEnabled = enabled) }
    fun toggleEspBox(enabled: Boolean) = updateConfig { it.copy(espBoxEnabled = enabled) }
    fun toggleEspName(enabled: Boolean) = updateConfig { it.copy(espNameEnabled = enabled) }
    fun toggleEspDistance(enabled: Boolean) = updateConfig { it.copy(espDistanceEnabled = enabled) }
    fun toggleEspHealth(enabled: Boolean) = updateConfig { it.copy(espHealthEnabled = enabled) }
    fun toggleOutline(enabled: Boolean) = updateConfig { it.copy(outlineEnabled = enabled) }
    fun toggleGlow(enabled: Boolean) = updateConfig { it.copy(glowEnabled = enabled) }
    fun toggleSnaplines(enabled: Boolean) = updateConfig { it.copy(snaplinesEnabled = enabled) }
    fun toggleRadar(enabled: Boolean) = updateConfig { it.copy(radarEnabled = enabled) }

    // Customization sliders
    fun setGlowIntensity(intensity: Float) = updateConfig { it.copy(glowIntensity = intensity) }
    fun setOutlineThickness(thickness: Float) = updateConfig { it.copy(outlineThickness = thickness) }
    fun setTransparency(alpha: Float) = updateConfig { it.copy(transparency = alpha) }
    fun setAccentColor(colorHex: Long) = updateConfig { it.copy(accentColorHex = colorHex) }
    fun setBoxCornerOnly(cornerOnly: Boolean) = updateConfig { it.copy(boxCornerOnly = cornerOnly) }

    fun resetDefaults() {
        preferencesManager.resetToDefaults()
    }

    private fun updateConfig(transform: (EspConfig) -> EspConfig) {
        val current = config.value
        val updated = transform(current)
        preferencesManager.updateConfig(updated)
    }
}
