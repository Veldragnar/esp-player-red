package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.EspPreferencesManager
import com.example.model.EspConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ESP PLAYER RED", appName)
  }

  @Test
  fun `verify preferences manager persists toggles`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefsManager = EspPreferencesManager(context)
    val defaultCfg = prefsManager.loadConfig()
    assertTrue(defaultCfg.chamsEnabled)
    assertTrue(defaultCfg.espBoxEnabled)

    val modified = defaultCfg.copy(glowIntensity = 0.5f, outlineThickness = 5.0f)
    prefsManager.updateConfig(modified)

    val reloaded = prefsManager.loadConfig()
    assertEquals(0.5f, reloaded.glowIntensity, 0.001f)
    assertEquals(5.0f, reloaded.outlineThickness, 0.001f)

    prefsManager.resetToDefaults()
    val afterReset = prefsManager.loadConfig()
    assertEquals(EspConfig.DEFAULT.glowIntensity, afterReset.glowIntensity, 0.001f)
  }
}
